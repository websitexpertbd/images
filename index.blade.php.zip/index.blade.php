<!DOCTYPE html>
<html lang="en">

<head>

    <meta charset="UTF-8">

    <meta
        name="viewport"
        content="width=device-width, initial-scale=1.0"
    >

    <title>MCW Shop</title>

    <link
    rel="stylesheet"
    href="{{ asset('css/product-card.css') }}"
>


    <style>

        /*
        |--------------------------------------------------------------------------
        | MCW HOMEPAGE BASE
        |--------------------------------------------------------------------------
        */

        html {
            width: 100%;
            min-height: 100%;

            margin: 0;
            padding: 0;

            scroll-behavior: smooth;
        }


        body {
            width: 100%;
            min-height: 100%;

            margin: 0;
            padding: 0;

            background: #ffffff;
            color: #111827;

            font-family:
                "Noto Sans Bengali",
                "Noto Sans",
                Arial,
                sans-serif;

            overflow-x: hidden;
        }


        *,
        *::before,
        *::after {
            box-sizing: border-box;
        }


        /*
        |--------------------------------------------------------------------------
        | FORM ELEMENT FONT
        |--------------------------------------------------------------------------
        */

        button,
        input,
        select,
        textarea {
            font-family:
                "Noto Sans Bengali",
                "Noto Sans",
                Arial,
                sans-serif;
        }


        /*
        |--------------------------------------------------------------------------
        | HOMEPAGE
        |--------------------------------------------------------------------------
        */

        .mcw-homepage {
            width: 100%;

            margin: 0;
            padding: 0;

            background: #ffffff;
        }


        .mcw-homepage-content {
            width: 100%;

            margin: 0;
            padding: 0;

            background: #ffffff;
        }


        /*
        |--------------------------------------------------------------------------
        | HERO SLIDER
        |--------------------------------------------------------------------------
        */

        .mcw-homepage-hero {
            position: relative;

            width: 100%;

            margin: 0;
            padding: 0;

            overflow: hidden;

            background: #111827;
        }


        .mcw-hero-slider {
            position: relative;

            width: 100%;
        }


        .mcw-hero-slide {
            position: relative;

            display: none;

            width: 100%;
            min-height: 620px;

            overflow: hidden;
        }


        .mcw-hero-slide.is-active {
            display: flex;
        }


        /*
        |--------------------------------------------------------------------------
        | HERO IMAGE
        |--------------------------------------------------------------------------
        */

        .mcw-hero-slide-image {
            position: absolute;

            inset: 0;

            width: 100%;
            height: 100%;

            object-fit: cover;
            object-position: center center;

            display: block;
        }


        /*
        |--------------------------------------------------------------------------
        | HERO OVERLAY
        |--------------------------------------------------------------------------
        */

        .mcw-hero-slide-overlay {
            position: absolute;

            inset: 0;

            z-index: 1;

            pointer-events: none;
        }


        /*
        |--------------------------------------------------------------------------
        | HERO CONTENT WRAPPER
        |--------------------------------------------------------------------------
        */

        .mcw-hero-slide-content-wrapper {
            position: relative;

            z-index: 2;

            display: flex;

            width: 100%;
            min-height: 620px;

            padding: 80px 20px;
        }


        /*
        |--------------------------------------------------------------------------
        | HORIZONTAL CONTENT POSITION
        |--------------------------------------------------------------------------
        */

        .mcw-hero-slide-content-wrapper.position-left {
            justify-content: flex-start;
        }


        .mcw-hero-slide-content-wrapper.position-center {
            justify-content: center;
        }


        .mcw-hero-slide-content-wrapper.position-right {
            justify-content: flex-end;
        }


        /*
        |--------------------------------------------------------------------------
        | VERTICAL CONTENT POSITION
        |--------------------------------------------------------------------------
        */

        .mcw-hero-slide-content-wrapper.vertical-top {
            align-items: flex-start;
        }


        .mcw-hero-slide-content-wrapper.vertical-center {
            align-items: center;
        }


        .mcw-hero-slide-content-wrapper.vertical-bottom {
            align-items: flex-end;
        }


        /*
        |--------------------------------------------------------------------------
        | HERO CONTENT
        |--------------------------------------------------------------------------
        */

        .mcw-hero-slide-content {
            width: 100%;
            max-width: 680px;

            margin: 0;

            color: #ffffff;
        }


        .mcw-hero-slide-content.align-left {
            text-align: left;
        }


        .mcw-hero-slide-content.align-center {
            text-align: center;
        }


        .mcw-hero-slide-content.align-right {
            text-align: right;
        }


        /*
        |--------------------------------------------------------------------------
        | HERO TITLE
        |--------------------------------------------------------------------------
        */

        .mcw-hero-slide-title {
            margin: 0 0 12px;

            color: #ffffff;

            font-size: clamp(34px, 5vw, 68px);
            font-weight: 800;

            line-height: 1.08;

            letter-spacing: -1px;

            text-shadow:
                0 3px 14px rgba(0, 0, 0, 0.35);
        }


        /*
        |--------------------------------------------------------------------------
        | HERO SUBTITLE
        |--------------------------------------------------------------------------
        */

        .mcw-hero-slide-subtitle {
            margin: 0 0 14px;

            color: #ffffff;

            font-size: clamp(18px, 2.4vw, 30px);
            font-weight: 600;

            line-height: 1.3;

            text-shadow:
                0 2px 10px rgba(0, 0, 0, 0.35);
        }


        /*
        |--------------------------------------------------------------------------
        | HERO DESCRIPTION
        |--------------------------------------------------------------------------
        */

        .mcw-hero-slide-description {
            max-width: 620px;

            margin: 0 0 28px;

            color: rgba(255, 255, 255, 0.95);

            font-size: 17px;
            font-weight: 400;

            line-height: 1.7;

            text-shadow:
                0 2px 8px rgba(0, 0, 0, 0.35);
        }


        /*
        |--------------------------------------------------------------------------
        | HERO BUTTON
        |--------------------------------------------------------------------------
        */

        .mcw-hero-slide-button {
            display: inline-flex;

            align-items: center;
            justify-content: center;

            min-height: 50px;

            padding: 13px 28px;

            border: 0;
            border-radius: 8px;

            background: #dc2626;
            color: #ffffff;

            font-size: 16px;
            font-weight: 700;

            line-height: 1.2;

            text-decoration: none;

            cursor: pointer;

            box-shadow:
                0 8px 24px rgba(0, 0, 0, 0.20);

            transition:
                transform 180ms ease,
                background 180ms ease,
                box-shadow 180ms ease;
        }


        .mcw-hero-slide-button:hover {
            background: #b91c1c;

            transform: translateY(-2px);

            box-shadow:
                0 12px 28px rgba(0, 0, 0, 0.25);
        }


        /*
        |--------------------------------------------------------------------------
        | HERO NAVIGATION
        |--------------------------------------------------------------------------
        */

        .mcw-hero-control {
            position: absolute;

            top: 50%;

            z-index: 5;

            width: 48px;
            height: 48px;

            margin: 0;

            padding: 0;

            border: 1px solid rgba(255, 255, 255, 0.35);
            border-radius: 50%;

            background: rgba(0, 0, 0, 0.28);
            color: #ffffff;

            font-size: 28px;
            font-weight: 400;

            line-height: 1;

            display: flex;
            align-items: center;
            justify-content: center;

            cursor: pointer;

            transform: translateY(-50%);

            backdrop-filter: blur(5px);

            transition:
                background 180ms ease,
                border-color 180ms ease,
                transform 180ms ease;
        }


        .mcw-hero-control:hover {
            background: rgba(0, 0, 0, 0.52);

            border-color: rgba(255, 255, 255, 0.65);

            transform:
                translateY(-50%)
                scale(1.05);
        }


        .mcw-hero-control.previous {
            left: 24px;
        }


        .mcw-hero-control.next {
            right: 24px;
        }


        /*
        |--------------------------------------------------------------------------
        | HERO INDICATORS
        |--------------------------------------------------------------------------
        */

        .mcw-hero-indicators {
            position: absolute;

            left: 50%;
            bottom: 24px;

            z-index: 5;

            display: flex;

            align-items: center;
            justify-content: center;

            gap: 8px;

            transform: translateX(-50%);
        }


        .mcw-hero-indicator {
            width: 9px;
            height: 9px;

            margin: 0;
            padding: 0;

            border: 0;
            border-radius: 50%;

            background: rgba(255, 255, 255, 0.55);

            cursor: pointer;

            transition:
                width 180ms ease,
                border-radius 180ms ease,
                background 180ms ease;
        }


        .mcw-hero-indicator.is-active {
            width: 28px;

            border-radius: 999px;

            background: #ffffff;
        }


        /*
        |--------------------------------------------------------------------------
        | COMMON HOMEPAGE SECTION
        |--------------------------------------------------------------------------
        */

        .mcw-homepage-section {
            width: 100%;

            margin: 0;
            padding: 80px 20px;

            background: #ffffff;
        }


        .mcw-homepage-section-inner {
            width: 100%;
            max-width: 1480px;

            margin: 0 auto;
        }


        /*
        |--------------------------------------------------------------------------
        | RESPONSIVE
        |--------------------------------------------------------------------------
        */

        @media (max-width: 768px) {

            .mcw-hero-slide {
                min-height: 560px;
            }


            .mcw-hero-slide-content-wrapper {
                min-height: 560px;

                padding: 60px 20px;
            }


            .mcw-hero-slide-content {
                max-width: 620px;
            }


            .mcw-hero-slide-description {
                font-size: 15px;

                line-height: 1.6;
            }


            .mcw-hero-control {
                width: 42px;
                height: 42px;

                font-size: 23px;
            }


            .mcw-hero-control.previous {
                left: 14px;
            }


            .mcw-hero-control.next {
                right: 14px;
            }


            .mcw-homepage-section {
                padding: 60px 16px;
            }

        }


        @media (max-width: 480px) {

            .mcw-hero-slide {
                min-height: 500px;
            }


            .mcw-hero-slide-content-wrapper {
                min-height: 500px;

                padding: 48px 18px;
            }


            .mcw-hero-slide-title {
                margin-bottom: 10px;

                font-size: 34px;

                letter-spacing: -0.5px;
            }


            .mcw-hero-slide-subtitle {
                font-size: 18px;
            }


            .mcw-hero-slide-description {
                margin-bottom: 22px;

                font-size: 14px;
            }


            .mcw-hero-slide-button {
                min-height: 46px;

                padding: 11px 22px;

                font-size: 15px;
            }


            .mcw-hero-control {
                width: 38px;
                height: 38px;

                font-size: 21px;
            }


            .mcw-hero-control.previous {
                left: 10px;
            }


            .mcw-hero-control.next {
                right: 10px;
            }


            .mcw-hero-indicators {
                bottom: 16px;
            }


            .mcw-homepage-section {
                padding: 48px 14px;
            }

        }

/*
|--------------------------------------------------------------------------
| FEATURED CATEGORIES
|--------------------------------------------------------------------------
*/

.mcw-featured-categories-section {
    padding-top: 88px;
    padding-bottom: 88px;

    background: #ffffff;
}


/*
|--------------------------------------------------------------------------
| HEADER
|--------------------------------------------------------------------------
*/

.mcw-featured-categories-header {
    display: flex;

    align-items: flex-end;
    justify-content: space-between;

    margin-bottom: 38px;
}


.mcw-featured-categories-heading {
    max-width: 700px;
}


.mcw-featured-categories-eyebrow {
    display: block;

    margin-bottom: 8px;

    color: #dc2626;

    font-size: 14px;
    font-weight: 700;

    line-height: 1.4;

    letter-spacing: 1px;

    text-transform: uppercase;
}


.mcw-featured-categories-title {
    margin: 0 0 12px;

    color: #111827;

    font-size: clamp(30px, 4vw, 46px);
    font-weight: 800;

    line-height: 1.15;

    letter-spacing: -0.7px;
}


.mcw-featured-categories-description {
    max-width: 620px;

    margin: 0;

    color: #6b7280;

    font-size: 16px;
    font-weight: 400;

    line-height: 1.7;
}


/*
|--------------------------------------------------------------------------
| CATEGORY GRID
|--------------------------------------------------------------------------
*/

.mcw-featured-categories-grid {
    display: grid;

    grid-template-columns:
        repeat(4, minmax(0, 1fr));

    gap: 24px;
}


/*
|--------------------------------------------------------------------------
| CATEGORY CARD
|--------------------------------------------------------------------------
*/

.mcw-featured-category-card {
    display: block;

    width: 100%;

    overflow: hidden;

    border: 1px solid #e5e7eb;
    border-radius: 16px;

    background: #ffffff;

    color: #111827;

    text-decoration: none;

    box-shadow:
        0 5px 20px rgba(17, 24, 39, 0.06);

    transition:
        transform 200ms ease,
        box-shadow 200ms ease,
        border-color 200ms ease;
}


.mcw-featured-category-card:hover {
    transform: translateY(-5px);

    border-color: rgba(220, 38, 38, 0.25);

    box-shadow:
        0 14px 34px rgba(17, 24, 39, 0.12);
}


/*
|--------------------------------------------------------------------------
| CATEGORY IMAGE
|--------------------------------------------------------------------------
*/

.mcw-featured-category-image-wrapper {
    position: relative;

    width: 100%;

    aspect-ratio: 1 / 0.82;

    overflow: hidden;

    background: #f3f4f6;
}


.mcw-featured-category-image {
    display: block;

    width: 100%;
    height: 100%;

    object-fit: cover;
    object-position: center;

    transition:
        transform 350ms ease;
}


.mcw-featured-category-card:hover
.mcw-featured-category-image {
    transform: scale(1.05);
}


/*
|--------------------------------------------------------------------------
| IMAGE OVERLAY
|--------------------------------------------------------------------------
*/

.mcw-featured-category-image-overlay {
    position: absolute;

    inset: 0;

    background:
        linear-gradient(
            to top,
            rgba(17, 24, 39, 0.42),
            rgba(17, 24, 39, 0.00) 60%
        );

    pointer-events: none;
}


/*
|--------------------------------------------------------------------------
| PLACEHOLDER
|--------------------------------------------------------------------------
*/

.mcw-featured-category-placeholder {
    display: flex;

    align-items: center;
    justify-content: center;

    width: 100%;
    height: 100%;

    background:
        linear-gradient(
            135deg,
            #f3f4f6,
            #e5e7eb
        );

    color: #9ca3af;

    font-size: 52px;
    font-weight: 800;
}


.mcw-featured-category-placeholder span {
    display: flex;

    align-items: center;
    justify-content: center;

    width: 92px;
    height: 92px;

    border-radius: 50%;

    background: #ffffff;

    box-shadow:
        0 8px 24px rgba(17, 24, 39, 0.08);
}


/*
|--------------------------------------------------------------------------
| ARROW
|--------------------------------------------------------------------------
*/

.mcw-featured-category-arrow {
    position: absolute;

    right: 16px;
    bottom: 16px;

    display: flex;

    align-items: center;
    justify-content: center;

    width: 40px;
    height: 40px;

    border-radius: 50%;

    background: rgba(255, 255, 255, 0.94);

    color: #dc2626;

    font-size: 20px;
    font-weight: 700;

    box-shadow:
        0 5px 15px rgba(0, 0, 0, 0.12);

    transition:
        background 180ms ease,
        color 180ms ease,
        transform 180ms ease;
}


.mcw-featured-category-card:hover
.mcw-featured-category-arrow {
    background: #dc2626;

    color: #ffffff;

    transform: translateX(3px);
}


/*
|--------------------------------------------------------------------------
| CATEGORY CONTENT
|--------------------------------------------------------------------------
*/

.mcw-featured-category-content {
    padding: 18px 18px 20px;
}


.mcw-featured-category-name {
    margin: 0 0 7px;

    color: #111827;

    font-size: 19px;
    font-weight: 700;

    line-height: 1.35;
}


.mcw-featured-category-meta {
    color: #6b7280;

    font-size: 14px;
    font-weight: 500;

    line-height: 1.4;
}


/*
|--------------------------------------------------------------------------
| EMPTY STATE
|--------------------------------------------------------------------------
*/

.mcw-featured-categories-empty {
    padding: 60px 20px;

    border: 1px dashed #d1d5db;
    border-radius: 16px;

    background: #f9fafb;

    text-align: center;
}


.mcw-featured-categories-empty h2 {
    margin: 0 0 10px;

    color: #111827;

    font-size: 28px;
    font-weight: 800;
}


.mcw-featured-categories-empty p {
    margin: 0;

    color: #6b7280;

    font-size: 15px;
    line-height: 1.6;
}


/*
|--------------------------------------------------------------------------
| RESPONSIVE — TABLET
|--------------------------------------------------------------------------
*/

@media (max-width: 1100px) {

    .mcw-featured-categories-grid {
        grid-template-columns:
            repeat(3, minmax(0, 1fr));
    }

}


/*
|--------------------------------------------------------------------------
| RESPONSIVE — MOBILE
|--------------------------------------------------------------------------
*/

@media (max-width: 768px) {

    .mcw-featured-categories-section {
        padding-top: 64px;
        padding-bottom: 64px;
    }


    .mcw-featured-categories-header {
        margin-bottom: 28px;
    }


    .mcw-featured-categories-grid {
        grid-template-columns:
            repeat(2, minmax(0, 1fr));

        gap: 16px;
    }


    .mcw-featured-category-content {
        padding: 15px 15px 17px;
    }


    .mcw-featured-category-name {
        font-size: 17px;
    }

}


/*
|--------------------------------------------------------------------------
| RESPONSIVE — SMALL MOBILE
|--------------------------------------------------------------------------
*/

@media (max-width: 480px) {

    .mcw-featured-categories-grid {
        grid-template-columns: 1fr;

        gap: 16px;
    }


    .mcw-featured-category-image-wrapper {
        aspect-ratio: 1 / 0.68;
    }


    .mcw-featured-categories-title {
        font-size: 30px;
    }


    .mcw-featured-categories-description {
        font-size: 15px;
    }

}

/*
|--------------------------------------------------------------------------
| FEATURED PRODUCTS
|--------------------------------------------------------------------------
*/

.mcw-featured-products {
    width: 100%;
}


.mcw-featured-products-header {
    width: 100%;

    margin-bottom: 42px;
}


.mcw-featured-products-heading {
    max-width: 720px;
}


.mcw-featured-products-kicker {
    display: inline-block;

    margin-bottom: 10px;

    font-size: 14px;
    font-weight: 700;

    letter-spacing: 0.08em;
    text-transform: uppercase;

    color: #dc2626;
}


.mcw-featured-products-heading h2 {
    margin: 0;

    font-size: 36px;
    line-height: 1.2;
    font-weight: 800;

    color: #111827;
}


.mcw-featured-products-heading p {
    margin: 14px 0 0;

    font-size: 16px;
    line-height: 1.7;

    color: #6b7280;
}


/*
|--------------------------------------------------------------------------
| PRODUCT GRID
|--------------------------------------------------------------------------
*/

.mcw-featured-products-grid {
    display: grid;

    grid-template-columns:
        repeat(4, minmax(0, 1fr));

    gap: 24px;

    width: 100%;
}


/*
|--------------------------------------------------------------------------
| PRODUCT CARD
|--------------------------------------------------------------------------
*/

.mcw-product-card {
    width: 100%;

    overflow: hidden;

    background: #ffffff;

    border: 1px solid #e5e7eb;
    border-radius: 18px;

    box-shadow:
        0 8px 24px rgba(17, 24, 39, 0.06);

    transition:
        transform 0.25s ease,
        box-shadow 0.25s ease;
}


.mcw-product-card:hover {
    transform: translateY(-5px);

    box-shadow:
        0 16px 36px rgba(17, 24, 39, 0.10);
}


/*
|--------------------------------------------------------------------------
| PRODUCT IMAGE
|--------------------------------------------------------------------------
*/

.mcw-product-card-image {
    position: relative;

    width: 100%;
    aspect-ratio: 1 / 1;

    overflow: hidden;

    background: #f3f4f6;
}


.mcw-product-card-image img {
    display: block;

    width: 100%;
    height: 100%;

    object-fit: cover;

    transition:
        transform 0.35s ease;
}


.mcw-product-card:hover
.mcw-product-card-image img {
    transform: scale(1.04);
}


.mcw-product-card-image-placeholder {
    display: flex;

    align-items: center;
    justify-content: center;

    width: 100%;
    height: 100%;

    color: #9ca3af;

    font-size: 14px;
}


/*
|--------------------------------------------------------------------------
| PRODUCT CONTENT
|--------------------------------------------------------------------------
*/

.mcw-product-card-content {
    padding: 20px;
}


.mcw-product-card-brand {
    display: block;

    margin-bottom: 6px;

    font-size: 12px;
    font-weight: 700;

    color: #16a34a;

    text-transform: uppercase;
    letter-spacing: 0.05em;
}


.mcw-product-card-title {
    margin: 0;

    font-size: 18px;
    line-height: 1.45;
    font-weight: 700;

    color: #111827;
}


.mcw-product-card-category {
    display: block;

    margin-top: 7px;

    font-size: 13px;

    color: #6b7280;
}


/*
|--------------------------------------------------------------------------
| PRODUCT FOOTER
|--------------------------------------------------------------------------
*/

.mcw-product-card-footer {
    display: flex;

    align-items: center;
    justify-content: space-between;

    gap: 14px;

    margin-top: 18px;
}


.mcw-product-card-price {
    display: flex;

    flex-direction: column;

    gap: 2px;
}


.mcw-product-card-current-price {
    font-size: 20px;
    line-height: 1.2;
    font-weight: 800;

    color: #dc2626;
}


.mcw-product-card-old-price {
    font-size: 13px;

    color: #9ca3af;

    text-decoration: line-through;
}


.mcw-product-card-button {
    flex-shrink: 0;

    min-height: 42px;

    padding: 0 16px;

    border: 0;
    border-radius: 10px;

    background: #16a34a;
    color: #ffffff;

    font-size: 13px;
    font-weight: 700;

    cursor: pointer;

    transition:
        background 0.2s ease,
        transform 0.2s ease;
}


.mcw-product-card-button:hover {
    background: #15803d;

    transform: translateY(-1px);
}


/*
|--------------------------------------------------------------------------
| EMPTY STATE
|--------------------------------------------------------------------------
*/

.mcw-featured-products-empty {
    width: 100%;

    padding: 48px 24px;

    text-align: center;

    border: 1px dashed #d1d5db;
    border-radius: 16px;

    background: #f9fafb;
}


.mcw-featured-products-empty p {
    margin: 0;

    color: #6b7280;

    font-size: 15px;
}


/*
|--------------------------------------------------------------------------
| RESPONSIVE
|--------------------------------------------------------------------------
*/

@media (max-width: 1100px) {

    .mcw-featured-products-grid {
        grid-template-columns:
            repeat(3, minmax(0, 1fr));
    }

}


@media (max-width: 768px) {

    .mcw-featured-products-heading h2 {
        font-size: 30px;
    }


    .mcw-featured-products-grid {
        grid-template-columns:
            repeat(2, minmax(0, 1fr));

        gap: 18px;
    }


    .mcw-product-card-content {
        padding: 16px;
    }


    .mcw-product-card-title {
        font-size: 16px;
    }


    .mcw-product-card-current-price {
        font-size: 18px;
    }

}


@media (max-width: 480px) {

    .mcw-featured-products-header {
        margin-bottom: 28px;
    }


    .mcw-featured-products-heading h2 {
        font-size: 26px;
    }


    .mcw-featured-products-heading p {
        font-size: 14px;
    }


    .mcw-featured-products-grid {
        grid-template-columns:
            1fr;
    }


    .mcw-product-card-footer {
        align-items: flex-end;
    }

}

/*
|--------------------------------------------------------------------------
| PRODUCT SECTIONS
|--------------------------------------------------------------------------
*/

.mcw-product-section {
    width: 100%;

    background: #ffffff;
}


/*
|--------------------------------------------------------------------------
| PRODUCT SECTION SPACING
|--------------------------------------------------------------------------
*/

.mcw-product-section + .mcw-product-section {
    padding-top: 0;
}


/*
|--------------------------------------------------------------------------
| PRODUCT SECTION HEADER
|--------------------------------------------------------------------------
*/

.mcw-product-section
.mcw-featured-products-header {
    width: 100%;

    margin-bottom: 42px;
}


.mcw-product-section
.mcw-featured-products-heading {
    max-width: 760px;
}


.mcw-product-section
.mcw-featured-products-kicker {
    display: inline-block;

    margin-bottom: 10px;

    color: #dc2626;

    font-size: 14px;
    font-weight: 700;

    line-height: 1.4;

    letter-spacing: 0.08em;

    text-transform: uppercase;
}


.mcw-product-section
.mcw-featured-products-heading h2 {
    margin: 0;

    color: #111827;

    font-size: clamp(30px, 4vw, 42px);
    font-weight: 800;

    line-height: 1.2;

    letter-spacing: -0.5px;
}


.mcw-product-section
.mcw-featured-products-heading p {
    max-width: 680px;

    margin: 14px 0 0;

    color: #6b7280;

    font-size: 16px;
    font-weight: 400;

    line-height: 1.7;
}


/*
|--------------------------------------------------------------------------
| PRODUCT GRID
|--------------------------------------------------------------------------
*/

.mcw-product-section
.mcw-featured-products-grid {
    display: grid;

    grid-template-columns:
        repeat(4, minmax(0, 1fr));

    gap: 24px;

    width: 100%;
}


/*
|--------------------------------------------------------------------------
| PRODUCT CARD
|--------------------------------------------------------------------------
*/

.mcw-product-section
.mcw-product-card {
    position: relative;

    width: 100%;

    overflow: hidden;

    background: #ffffff;

    border: 1px solid #e5e7eb;
    border-radius: 18px;

    box-shadow:
        0 8px 24px rgba(17, 24, 39, 0.06);

    transition:
        transform 250ms ease,
        box-shadow 250ms ease,
        border-color 250ms ease;
}


.mcw-product-section
.mcw-product-card:hover {
    transform: translateY(-5px);

    border-color: rgba(220, 38, 38, 0.18);

    box-shadow:
        0 16px 36px rgba(17, 24, 39, 0.11);
}


/*
|--------------------------------------------------------------------------
| PRODUCT IMAGE
|--------------------------------------------------------------------------
*/

.mcw-product-section
.mcw-product-card-image {
    position: relative;

    width: 100%;

    aspect-ratio: 1 / 1;

    overflow: hidden;

    background: #f3f4f6;
}


.mcw-product-section
.mcw-product-card-image img {
    display: block;

    width: 100%;
    height: 100%;

    object-fit: cover;
    object-position: center;

    transition:
        transform 350ms ease;
}


.mcw-product-section
.mcw-product-card:hover
.mcw-product-card-image img {
    transform: scale(1.04);
}


/*
|--------------------------------------------------------------------------
| IMAGE PLACEHOLDER
|--------------------------------------------------------------------------
*/

.mcw-product-section
.mcw-product-card-image-placeholder {
    display: flex;

    align-items: center;
    justify-content: center;

    width: 100%;
    height: 100%;

    background:
        linear-gradient(
            135deg,
            #f3f4f6,
            #e5e7eb
        );

    color: #9ca3af;

    font-size: 14px;
    font-weight: 600;
}


/*
|--------------------------------------------------------------------------
| PRODUCT CONTENT
|--------------------------------------------------------------------------
*/

.mcw-product-section
.mcw-product-card-content {
    padding: 20px;
}


.mcw-product-section
.mcw-product-card-brand {
    display: block;

    margin-bottom: 6px;

    color: #16a34a;

    font-size: 12px;
    font-weight: 700;

    line-height: 1.4;

    letter-spacing: 0.05em;

    text-transform: uppercase;
}


.mcw-product-section
.mcw-product-card-title {
    margin: 0;

    color: #111827;

    font-size: 18px;
    font-weight: 700;

    line-height: 1.45;
}


.mcw-product-section
.mcw-product-card-category {
    display: block;

    margin-top: 7px;

    color: #6b7280;

    font-size: 13px;
    font-weight: 500;

    line-height: 1.4;
}


/*
|--------------------------------------------------------------------------
| PRODUCT FOOTER
|--------------------------------------------------------------------------
*/

.mcw-product-section
.mcw-product-card-footer {
    display: flex;

    align-items: center;
    justify-content: space-between;

    gap: 14px;

    margin-top: 18px;
}


.mcw-product-section
.mcw-product-card-price {
    display: flex;

    flex-direction: column;

    gap: 2px;

    min-width: 0;
}


.mcw-product-section
.mcw-product-card-current-price {
    color: #dc2626;

    font-size: 20px;
    font-weight: 800;

    line-height: 1.2;

    white-space: nowrap;
}


.mcw-product-section
.mcw-product-card-old-price {
    color: #9ca3af;

    font-size: 13px;
    font-weight: 500;

    line-height: 1.3;

    text-decoration: line-through;

    white-space: nowrap;
}


/*
|--------------------------------------------------------------------------
| BUY NOW BUTTON
|--------------------------------------------------------------------------
*/

.mcw-product-section
.mcw-product-card-button {
    flex-shrink: 0;

    min-height: 42px;

    padding: 0 16px;

    border: 0;
    border-radius: 10px;

    background: #16a34a;
    color: #ffffff;

    font-size: 13px;
    font-weight: 700;

    line-height: 1.2;

    cursor: pointer;

    transition:
        background 200ms ease,
        transform 200ms ease,
        box-shadow 200ms ease;
}


.mcw-product-section
.mcw-product-card-button:hover {
    background: #15803d;

    transform: translateY(-1px);

    box-shadow:
        0 6px 16px rgba(22, 163, 74, 0.22);
}


/*
|--------------------------------------------------------------------------
| EMPTY STATE
|--------------------------------------------------------------------------
*/

.mcw-product-section
.mcw-featured-products-empty {
    width: 100%;

    padding: 52px 24px;

    border: 1px dashed #d1d5db;
    border-radius: 16px;

    background: #f9fafb;

    text-align: center;
}


.mcw-product-section
.mcw-featured-products-empty p {
    margin: 0;

    color: #6b7280;

    font-size: 15px;
    font-weight: 500;

    line-height: 1.6;
}


/*
|--------------------------------------------------------------------------
| TABLET
|--------------------------------------------------------------------------
*/

@media (max-width: 1100px) {

    .mcw-product-section
    .mcw-featured-products-grid {
        grid-template-columns:
            repeat(3, minmax(0, 1fr));
    }

}


/*
|--------------------------------------------------------------------------
| MOBILE
|--------------------------------------------------------------------------
*/

@media (max-width: 768px) {

    .mcw-product-section
    .mcw-featured-products-header {
        margin-bottom: 30px;
    }


    .mcw-product-section
    .mcw-featured-products-heading h2 {
        font-size: 30px;
    }


    .mcw-product-section
    .mcw-featured-products-heading p {
        font-size: 15px;

        line-height: 1.6;
    }


    .mcw-product-section
    .mcw-featured-products-grid {
        grid-template-columns:
            repeat(2, minmax(0, 1fr));

        gap: 18px;
    }


    .mcw-product-section
    .mcw-product-card-content {
        padding: 16px;
    }


    .mcw-product-section
    .mcw-product-card-title {
        font-size: 16px;
    }


    .mcw-product-section
    .mcw-product-card-current-price {
        font-size: 18px;
    }


    .mcw-product-section
    .mcw-product-card-button {
        min-height: 40px;

        padding: 0 13px;

        font-size: 12px;
    }

}


/*
|--------------------------------------------------------------------------
| SMALL MOBILE
|--------------------------------------------------------------------------
*/

@media (max-width: 480px) {

    .mcw-product-section
    .mcw-featured-products-header {
        margin-bottom: 26px;
    }


    .mcw-product-section
    .mcw-featured-products-heading h2 {
        font-size: 26px;
    }


    .mcw-product-section
    .mcw-featured-products-heading p {
        font-size: 14px;
    }


    .mcw-product-section
    .mcw-featured-products-grid {
        grid-template-columns: 1fr;

        gap: 16px;
    }


    .mcw-product-section
    .mcw-product-card-content {
        padding: 16px;
    }


    .mcw-product-section
    .mcw-product-card-footer {
        align-items: flex-end;
    }

}

/*
|--------------------------------------------------------------------------
| BRAND SHOWCASE
|--------------------------------------------------------------------------
*/

.mcw-brand-showcase {
    width: 100%;
}


.mcw-brand-showcase-header {
    width: 100%;

    margin-bottom: 42px;
}


.mcw-brand-showcase-heading {
    max-width: 720px;
}


.mcw-brand-showcase-kicker {
    display: inline-block;

    margin-bottom: 10px;

    color: #16a34a;

    font-size: 14px;
    font-weight: 700;

    line-height: 1.4;

    letter-spacing: 0.08em;

    text-transform: uppercase;
}


.mcw-brand-showcase-title {
    margin: 0;

    color: #111827;

    font-size: 36px;
    font-weight: 800;

    line-height: 1.2;
}


.mcw-brand-showcase-description {
    margin: 14px 0 0;

    color: #6b7280;

    font-size: 16px;
    font-weight: 400;

    line-height: 1.7;
}


/*
|--------------------------------------------------------------------------
| BRAND GRID
|--------------------------------------------------------------------------
*/

.mcw-brand-showcase-grid {
    display: grid;

    grid-template-columns:
        repeat(5, minmax(0, 1fr));

    gap: 20px;

    width: 100%;
}


/*
|--------------------------------------------------------------------------
| BRAND CARD
|--------------------------------------------------------------------------
*/

.mcw-brand-card {
    position: relative;

    display: flex;

    flex-direction: column;

    align-items: center;
    justify-content: center;

    min-height: 190px;

    padding: 28px 20px;

    border: 1px solid #e5e7eb;
    border-radius: 16px;

    background: #ffffff;

    color: #111827;

    text-decoration: none;

    box-shadow:
        0 6px 20px rgba(17, 24, 39, 0.05);

    transition:
        transform 200ms ease,
        box-shadow 200ms ease,
        border-color 200ms ease;
}


.mcw-brand-card:hover {
    transform: translateY(-5px);

    border-color: rgba(22, 163, 74, 0.30);

    box-shadow:
        0 14px 32px rgba(17, 24, 39, 0.10);
}


/*
|--------------------------------------------------------------------------
| BRAND LOGO
|--------------------------------------------------------------------------
*/

.mcw-brand-card-logo {
    display: flex;

    align-items: center;
    justify-content: center;

    width: 92px;
    height: 92px;

    margin-bottom: 18px;

    overflow: hidden;

    border-radius: 14px;

    background: #f9fafb;

    border: 1px solid #f3f4f6;
}


.mcw-brand-card-logo img {
    display: block;

    width: 100%;
    height: 100%;

    padding: 10px;

    object-fit: contain;

    transition:
        transform 250ms ease;
}


.mcw-brand-card:hover
.mcw-brand-card-logo img {
    transform: scale(1.06);
}


/*
|--------------------------------------------------------------------------
| BRAND PLACEHOLDER
|--------------------------------------------------------------------------
*/

.mcw-brand-card-placeholder {
    display: flex;

    align-items: center;
    justify-content: center;

    width: 92px;
    height: 92px;

    margin-bottom: 18px;

    border-radius: 14px;

    background:
        linear-gradient(
            135deg,
            #f3f4f6,
            #e5e7eb
        );

    color: #16a34a;

    font-size: 34px;
    font-weight: 800;
}


/*
|--------------------------------------------------------------------------
| BRAND NAME
|--------------------------------------------------------------------------
*/

.mcw-brand-card-name {
    margin: 0;

    color: #111827;

    font-size: 17px;
    font-weight: 700;

    line-height: 1.4;

    text-align: center;
}


/*
|--------------------------------------------------------------------------
| BRAND PRODUCT COUNT
|--------------------------------------------------------------------------
*/

.mcw-brand-card-products {
    margin-top: 6px;

    color: #6b7280;

    font-size: 13px;
    font-weight: 500;

    line-height: 1.4;

    text-align: center;
}


/*
|--------------------------------------------------------------------------
| BRAND ARROW
|--------------------------------------------------------------------------
*/

.mcw-brand-card-arrow {
    position: absolute;

    top: 14px;
    right: 14px;

    display: flex;

    align-items: center;
    justify-content: center;

    width: 30px;
    height: 30px;

    border-radius: 50%;

    background: #f0fdf4;

    color: #16a34a;

    font-size: 16px;
    font-weight: 700;

    opacity: 0;

    transform: translateX(-4px);

    transition:
        opacity 180ms ease,
        transform 180ms ease,
        background 180ms ease,
        color 180ms ease;
}


.mcw-brand-card:hover
.mcw-brand-card-arrow {
    opacity: 1;

    transform: translateX(0);

    background: #16a34a;

    color: #ffffff;
}


/*
|--------------------------------------------------------------------------
| EMPTY STATE
|--------------------------------------------------------------------------
*/

.mcw-brand-showcase-empty {
    width: 100%;

    padding: 48px 24px;

    border: 1px dashed #d1d5db;
    border-radius: 16px;

    background: #f9fafb;

    text-align: center;
}


.mcw-brand-showcase-empty h3 {
    margin: 0 0 8px;

    color: #111827;

    font-size: 26px;
    font-weight: 800;
}


.mcw-brand-showcase-empty p {
    margin: 0;

    color: #6b7280;

    font-size: 15px;

    line-height: 1.6;
}


/*
|--------------------------------------------------------------------------
| RESPONSIVE — LARGE TABLET
|--------------------------------------------------------------------------
*/

@media (max-width: 1200px) {

    .mcw-brand-showcase-grid {
        grid-template-columns:
            repeat(4, minmax(0, 1fr));
    }

}


/*
|--------------------------------------------------------------------------
| RESPONSIVE — TABLET
|--------------------------------------------------------------------------
*/

@media (max-width: 900px) {

    .mcw-brand-showcase-grid {
        grid-template-columns:
            repeat(3, minmax(0, 1fr));

        gap: 18px;
    }


    .mcw-brand-card {
        min-height: 180px;

        padding: 24px 16px;
    }

}


/*
|--------------------------------------------------------------------------
| RESPONSIVE — MOBILE
|--------------------------------------------------------------------------
*/

@media (max-width: 768px) {

    .mcw-brand-showcase-header {
        margin-bottom: 30px;
    }


    .mcw-brand-showcase-title {
        font-size: 30px;
    }


    .mcw-brand-showcase-description {
        font-size: 15px;
    }


    .mcw-brand-showcase-grid {
        grid-template-columns:
            repeat(2, minmax(0, 1fr));

        gap: 16px;
    }


    .mcw-brand-card {
        min-height: 170px;

        padding: 22px 14px;
    }


    .mcw-brand-card-logo,
    .mcw-brand-card-placeholder {
        width: 78px;
        height: 78px;

        margin-bottom: 14px;
    }


    .mcw-brand-card-placeholder {
        font-size: 28px;
    }


    .mcw-brand-card-name {
        font-size: 16px;
    }

}


/*
|--------------------------------------------------------------------------
| RESPONSIVE — SMALL MOBILE
|--------------------------------------------------------------------------
*/

@media (max-width: 480px) {

    .mcw-brand-showcase-title {
        font-size: 26px;
    }


    .mcw-brand-showcase-description {
        font-size: 14px;
    }


    .mcw-brand-showcase-grid {
        grid-template-columns:
            repeat(2, minmax(0, 1fr));

        gap: 12px;
    }


    .mcw-brand-card {
        min-height: 155px;

        padding: 18px 10px;
    }


    .mcw-brand-card-logo,
    .mcw-brand-card-placeholder {
        width: 68px;
        height: 68px;

        margin-bottom: 12px;
    }


    .mcw-brand-card-name {
        font-size: 14px;
    }


    .mcw-brand-card-products {
        font-size: 12px;
    }

}


/*
|--------------------------------------------------------------------------
| PROMOTIONAL CONTENT
|--------------------------------------------------------------------------
*/

.mcw-promotional-content-section {
    width: 100%;

    padding-top: 80px;
    padding-bottom: 80px;

    background: #ffffff;
}


.mcw-promotional-content-card {
    position: relative;

    width: 100%;
    min-height: 500px;

    overflow: hidden;

    border-radius: 20px;

    background: #111827;

    box-shadow:
        0 14px 40px rgba(17, 24, 39, 0.12);
}


/*
|--------------------------------------------------------------------------
| PROMOTIONAL IMAGE
|--------------------------------------------------------------------------
*/

.mcw-promotional-content-image {
    position: absolute;

    inset: 0;

    z-index: 0;

    display: block;

    width: 100%;
    height: 100%;

    object-fit: cover;
    object-position: center center;
}


.mcw-promotional-content-image-placeholder {
    position: absolute;

    inset: 0;

    z-index: 0;

    width: 100%;
    height: 100%;

    background:
        linear-gradient(
            135deg,
            #166534,
            #dc2626
        );
}


/*
|--------------------------------------------------------------------------
| OVERLAY
|--------------------------------------------------------------------------
*/

.mcw-promotional-content-overlay {
    position: absolute;

    inset: 0;

    z-index: 1;

    background:
        linear-gradient(
            90deg,
            rgba(17, 24, 39, 0.78) 0%,
            rgba(17, 24, 39, 0.55) 42%,
            rgba(17, 24, 39, 0.18) 75%,
            rgba(17, 24, 39, 0.05) 100%
        );

    pointer-events: none;
}


/*
|--------------------------------------------------------------------------
| CONTENT WRAPPER
|--------------------------------------------------------------------------
*/

.mcw-promotional-content-inner {
    position: relative;

    z-index: 2;

    display: flex;

    width: 100%;
    min-height: 500px;

    padding: 70px 70px;
}


.mcw-promotional-content-inner.left {
    justify-content: flex-start;

    text-align: left;
}


.mcw-promotional-content-inner.center {
    justify-content: center;

    text-align: center;
}


.mcw-promotional-content-inner.right {
    justify-content: flex-end;

    text-align: right;
}


/*
|--------------------------------------------------------------------------
| CONTENT
|--------------------------------------------------------------------------
*/

.mcw-promotional-content-content {
    align-self: center;

    width: 100%;
    max-width: 680px;

    color: #ffffff;
}


/*
|--------------------------------------------------------------------------
| TITLE
|--------------------------------------------------------------------------
*/

.mcw-promotional-content-title {
    margin: 0 0 14px;

    color: #ffffff;

    font-size: clamp(32px, 5vw, 58px);
    font-weight: 800;

    line-height: 1.1;

    letter-spacing: -0.8px;

    text-shadow:
        0 3px 14px rgba(0, 0, 0, 0.35);
}


/*
|--------------------------------------------------------------------------
| SUBTITLE
|--------------------------------------------------------------------------
*/

.mcw-promotional-content-subtitle {
    margin: 0 0 14px;

    color: rgba(255, 255, 255, 0.96);

    font-size: clamp(18px, 2.5vw, 28px);
    font-weight: 600;

    line-height: 1.35;

    text-shadow:
        0 2px 10px rgba(0, 0, 0, 0.30);
}


/*
|--------------------------------------------------------------------------
| DESCRIPTION
|--------------------------------------------------------------------------
*/

.mcw-promotional-content-description {
    max-width: 620px;

    margin: 0 0 28px;

    color: rgba(255, 255, 255, 0.94);

    font-size: 16px;
    font-weight: 400;

    line-height: 1.75;

    text-shadow:
        0 2px 8px rgba(0, 0, 0, 0.30);
}


/*
|--------------------------------------------------------------------------
| BUTTON
|--------------------------------------------------------------------------
*/

.mcw-promotional-content-button {
    display: inline-flex;

    align-items: center;
    justify-content: center;

    min-height: 48px;

    padding: 12px 26px;

    border-radius: 9px;

    background: #dc2626;
    color: #ffffff;

    font-size: 15px;
    font-weight: 700;

    line-height: 1.2;

    text-decoration: none;

    box-shadow:
        0 8px 24px rgba(0, 0, 0, 0.22);

    transition:
        transform 180ms ease,
        background 180ms ease,
        box-shadow 180ms ease;
}


.mcw-promotional-content-button:hover {
    background: #b91c1c;

    color: #ffffff;

    transform: translateY(-2px);

    box-shadow:
        0 12px 28px rgba(0, 0, 0, 0.28);
}


/*
|--------------------------------------------------------------------------
| TABLET
|--------------------------------------------------------------------------
*/

@media (max-width: 768px) {

    .mcw-promotional-content-section {
        padding-top: 64px;
        padding-bottom: 64px;
    }


    .mcw-promotional-content-card {
        min-height: 460px;

        border-radius: 16px;
    }


    .mcw-promotional-content-inner {
        min-height: 460px;

        padding: 55px 35px;
    }


    .mcw-promotional-content-title {
        font-size: 38px;
    }


    .mcw-promotional-content-subtitle {
        font-size: 21px;
    }


    .mcw-promotional-content-description {
        font-size: 15px;
    }

}


/*
|--------------------------------------------------------------------------
| MOBILE
|--------------------------------------------------------------------------
*/

@media (max-width: 480px) {

    .mcw-promotional-content-section {
        padding-top: 48px;
        padding-bottom: 48px;
    }


    .mcw-promotional-content-card {
        min-height: 480px;

        border-radius: 14px;
    }


    .mcw-promotional-content-overlay {
        background:
            linear-gradient(
                90deg,
                rgba(17, 24, 39, 0.82),
                rgba(17, 24, 39, 0.48)
            );
    }


    .mcw-promotional-content-inner {
        min-height: 480px;

        padding: 40px 22px;
    }


    .mcw-promotional-content-title {
        margin-bottom: 11px;

        font-size: 32px;
    }


    .mcw-promotional-content-subtitle {
        margin-bottom: 11px;

        font-size: 18px;
    }


    .mcw-promotional-content-description {
        margin-bottom: 22px;

        font-size: 14px;

        line-height: 1.65;
    }


    .mcw-promotional-content-button {
        min-height: 45px;

        padding: 11px 21px;

        font-size: 14px;
    }

}


/*
|--------------------------------------------------------------------------
| YOUTUBE / MEDIA
|--------------------------------------------------------------------------
*/

.mcw-youtube-section {
    width: 100%;

    padding-top: 88px;
    padding-bottom: 88px;

    background: #ffffff;
}


.mcw-youtube-header {
    max-width: 760px;

    margin: 0 auto 38px;

    text-align: center;
}


.mcw-youtube-kicker {
    display: inline-block;

    margin-bottom: 10px;

    color: #dc2626;

    font-size: 14px;
    font-weight: 800;

    line-height: 1.4;

    letter-spacing: 0.08em;

    text-transform: uppercase;
}


.mcw-youtube-title {
    margin: 0 0 14px;

    color: #111827;

    font-size: clamp(30px, 4vw, 46px);
    font-weight: 800;

    line-height: 1.15;

    letter-spacing: -0.6px;
}


.mcw-youtube-description {
    margin: 0;

    color: #6b7280;

    font-size: 16px;
    line-height: 1.7;
}


.mcw-youtube-video-wrapper {
    width: 100%;
    max-width: 1100px;

    margin: 0 auto;

    overflow: hidden;

    border-radius: 22px;

    background: #111827;

    box-shadow:
        0 18px 45px rgba(17, 24, 39, 0.12);
}


.mcw-youtube-video {
    position: relative;

    width: 100%;

    aspect-ratio: 16 / 9;

    overflow: hidden;
}


.mcw-youtube-video iframe {
    position: absolute;

    inset: 0;

    width: 100%;
    height: 100%;

    border: 0;

    display: block;
}


.mcw-youtube-action {
    display: flex;

    align-items: center;
    justify-content: center;

    margin-top: 28px;
}


.mcw-youtube-button {
    display: inline-flex;

    align-items: center;
    justify-content: center;

    min-height: 48px;

    padding: 12px 24px;

    border-radius: 10px;

    background: #dc2626;
    color: #ffffff;

    font-size: 15px;
    font-weight: 700;

    line-height: 1.2;

    text-decoration: none;

    transition:
        background 180ms ease,
        transform 180ms ease,
        box-shadow 180ms ease;
}


.mcw-youtube-button:hover {
    background: #b91c1c;

    transform: translateY(-2px);

    box-shadow:
        0 10px 24px rgba(220, 38, 38, 0.22);
}


.mcw-youtube-empty {
    padding: 48px 24px;

    border: 1px dashed #d1d5db;
    border-radius: 18px;

    background: #f9fafb;

    text-align: center;
}


.mcw-youtube-empty h2 {
    margin: 0 0 10px;

    color: #111827;

    font-size: 28px;
    font-weight: 800;
}


.mcw-youtube-empty p {
    margin: 0;

    color: #6b7280;

    font-size: 15px;

    line-height: 1.6;
}


@media (max-width: 768px) {

    .mcw-youtube-section {
        padding-top: 64px;
        padding-bottom: 64px;
    }


    .mcw-youtube-header {
        margin-bottom: 28px;
    }


    .mcw-youtube-title {
        font-size: 30px;
    }


    .mcw-youtube-description {
        font-size: 15px;
    }


    .mcw-youtube-video-wrapper {
        border-radius: 16px;
    }

}


@media (max-width: 480px) {

    .mcw-youtube-title {
        font-size: 27px;
    }


    .mcw-youtube-video-wrapper {
        border-radius: 12px;
    }

}

/*
|--------------------------------------------------------------------------
| TRUST / BENEFITS
|--------------------------------------------------------------------------
*/

.mcw-trust-section {
    width: 100%;

    padding-top: 88px;
    padding-bottom: 88px;

    background: #f9fafb;
}


.mcw-trust-header {
    max-width: 760px;

    margin: 0 auto 42px;

    text-align: center;
}


.mcw-trust-kicker {
    display: inline-block;

    margin-bottom: 10px;

    color: #16a34a;

    font-size: 14px;
    font-weight: 800;

    line-height: 1.4;

    letter-spacing: 0.08em;

    text-transform: uppercase;
}


.mcw-trust-title {
    margin: 0 0 14px;

    color: #111827;

    font-size: clamp(30px, 4vw, 46px);
    font-weight: 800;

    line-height: 1.15;

    letter-spacing: -0.6px;
}


.mcw-trust-description {
    margin: 0;

    color: #6b7280;

    font-size: 16px;

    line-height: 1.7;
}


.mcw-trust-grid {
    display: grid;

    grid-template-columns:
        repeat(4, minmax(0, 1fr));

    gap: 22px;
}


.mcw-trust-card {
    width: 100%;

    padding: 30px 24px;

    border: 1px solid #e5e7eb;
    border-radius: 18px;

    background: #ffffff;

    text-align: center;

    box-shadow:
        0 7px 24px rgba(17, 24, 39, 0.05);

    transition:
        transform 200ms ease,
        box-shadow 200ms ease,
        border-color 200ms ease;
}


.mcw-trust-card:hover {
    transform: translateY(-5px);

    border-color: rgba(22, 163, 74, 0.25);

    box-shadow:
        0 15px 34px rgba(17, 24, 39, 0.09);
}


.mcw-trust-icon {
    display: flex;

    align-items: center;
    justify-content: center;

    width: 58px;
    height: 58px;

    margin: 0 auto 18px;

    border-radius: 50%;

    background: #dcfce7;

    color: #16a34a;

    font-size: 25px;
    font-weight: 800;
}


.mcw-trust-card-title {
    margin: 0 0 9px;

    color: #111827;

    font-size: 18px;
    font-weight: 800;

    line-height: 1.4;
}


.mcw-trust-card-description {
    margin: 0;

    color: #6b7280;

    font-size: 14px;

    line-height: 1.65;
}


.mcw-trust-empty {
    padding: 48px 24px;

    border: 1px dashed #d1d5db;
    border-radius: 18px;

    background: #ffffff;

    text-align: center;
}


.mcw-trust-empty h2 {
    margin: 0 0 10px;

    color: #111827;

    font-size: 28px;
    font-weight: 800;
}


.mcw-trust-empty p {
    margin: 0;

    color: #6b7280;

    font-size: 15px;

    line-height: 1.6;
}


@media (max-width: 1100px) {

    .mcw-trust-grid {
        grid-template-columns:
            repeat(2, minmax(0, 1fr));
    }

}


@media (max-width: 768px) {

    .mcw-trust-section {
        padding-top: 64px;
        padding-bottom: 64px;
    }


    .mcw-trust-header {
        margin-bottom: 30px;
    }


    .mcw-trust-title {
        font-size: 30px;
    }


    .mcw-trust-description {
        font-size: 15px;
    }


    .mcw-trust-grid {
        gap: 16px;
    }


    .mcw-trust-card {
        padding: 24px 18px;
    }

}


@media (max-width: 480px) {

    .mcw-trust-grid {
        grid-template-columns: 1fr;
    }


    .mcw-trust-title {
        font-size: 27px;
    }

}


/*
|--------------------------------------------------------------------------
| FAQ
|--------------------------------------------------------------------------
*/

.mcw-faq-section {
    width: 100%;

    padding-top: 88px;
    padding-bottom: 88px;

    background: #ffffff;
}


.mcw-faq-header {
    max-width: 760px;

    margin: 0 auto 42px;

    text-align: center;
}


.mcw-faq-kicker {
    display: inline-block;

    margin-bottom: 10px;

    color: #dc2626;

    font-size: 14px;
    font-weight: 800;

    line-height: 1.4;

    letter-spacing: 0.08em;

    text-transform: uppercase;
}


.mcw-faq-title {
    margin: 0 0 14px;

    color: #111827;

    font-size: clamp(30px, 4vw, 46px);
    font-weight: 800;

    line-height: 1.15;

    letter-spacing: -0.6px;
}


.mcw-faq-description {
    margin: 0;

    color: #6b7280;

    font-size: 16px;

    line-height: 1.7;
}


.mcw-faq-list {
    width: 100%;
    max-width: 900px;

    margin: 0 auto;
}


.mcw-faq-item {
    margin-bottom: 14px;

    overflow: hidden;

    border: 1px solid #e5e7eb;
    border-radius: 14px;

    background: #ffffff;

    box-shadow:
        0 5px 18px rgba(17, 24, 39, 0.04);

    transition:
        border-color 180ms ease,
        box-shadow 180ms ease;
}


.mcw-faq-item:hover {
    border-color: rgba(220, 38, 38, 0.22);

    box-shadow:
        0 9px 24px rgba(17, 24, 39, 0.07);
}


.mcw-faq-question {
    display: flex;

    align-items: center;
    justify-content: space-between;

    width: 100%;

    gap: 20px;

    margin: 0;
    padding: 20px 22px;

    border: 0;

    background: #ffffff;
    color: #111827;

    font-size: 16px;
    font-weight: 700;

    line-height: 1.5;

    text-align: left;

    cursor: pointer;
}


.mcw-faq-question-icon {
    flex-shrink: 0;

    display: flex;

    align-items: center;
    justify-content: center;

    width: 30px;
    height: 30px;

    border-radius: 50%;

    background: #f3f4f6;

    color: #dc2626;

    font-size: 20px;
    font-weight: 600;

    line-height: 1;

    transition:
        transform 180ms ease,
        background 180ms ease;
}


.mcw-faq-item.is-open
.mcw-faq-question-icon {
    background: #dc2626;

    color: #ffffff;

    transform: rotate(45deg);
}


.mcw-faq-answer {
    display: grid;

    grid-template-rows: 0fr;

    transition:
        grid-template-rows 220ms ease;
}


.mcw-faq-answer-inner {
    min-height: 0;

    overflow: hidden;
}


.mcw-faq-answer-content {
    padding: 0 22px 22px;

    color: #6b7280;

    font-size: 15px;

    line-height: 1.7;
}


.mcw-faq-item.is-open
.mcw-faq-answer {
    grid-template-rows: 1fr;
}


.mcw-faq-empty {
    padding: 48px 24px;

    border: 1px dashed #d1d5db;
    border-radius: 18px;

    background: #f9fafb;

    text-align: center;
}


.mcw-faq-empty h2 {
    margin: 0 0 10px;

    color: #111827;

    font-size: 28px;
    font-weight: 800;
}


.mcw-faq-empty p {
    margin: 0;

    color: #6b7280;

    font-size: 15px;

    line-height: 1.6;
}


@media (max-width: 768px) {

    .mcw-faq-section {
        padding-top: 64px;
        padding-bottom: 64px;
    }


    .mcw-faq-header {
        margin-bottom: 30px;
    }


    .mcw-faq-title {
        font-size: 30px;
    }


    .mcw-faq-description {
        font-size: 15px;
    }


    .mcw-faq-question {
        padding: 17px 18px;

        font-size: 15px;
    }


    .mcw-faq-answer-content {
        padding: 0 18px 18px;

        font-size: 14px;
    }

}


@media (max-width: 480px) {

    .mcw-faq-title {
        font-size: 27px;
    }


    .mcw-faq-question {
        gap: 12px;
    }

}


    </style>

</head>


<body>


    {{-- ======================================================================
         EXISTING MCW HEADER

         DO NOT RECREATE HEADER HERE.
         Existing file:
         resources/views/frontend/partials/header.blade.php
    ======================================================================= --}}

    @include('frontend.partials.header')



    {{-- ======================================================================
         EXISTING MCW NAVBAR

         DO NOT RECREATE NAVBAR HERE.
         Existing file:
         resources/views/frontend/partials/navbar.blade.php
    ======================================================================= --}}

    @include('frontend.partials.navbar')



    {{-- ======================================================================
         MCW MAIN HOMEPAGE
    ======================================================================= --}}

    <main
        class="mcw-homepage"
        id="mcw-homepage"
    >

        <div class="mcw-homepage-content">


            {{-- ==================================================================
                 1. HERO / STORE INTRODUCTION
            =================================================================== --}}

            <section
                class="mcw-homepage-hero"
                id="hero"
            >

                @if ($heroSlides->isNotEmpty())

                    <div
                        class="mcw-hero-slider"
                        id="mcwHeroSlider"
                    >

                        @foreach ($heroSlides as $index => $slide)

                            @php
                                $contentPosition = $slide->content_position ?: 'left';
                                $contentVertical = $slide->content_vertical ?: 'center';

                                $textAlignment = $contentPosition;

                                $overlayColor = $slide->overlay_color ?: '#000000';
                                $overlayOpacity = ((int) ($slide->overlay_opacity ?? 35)) / 100;

                                $overlayRgba = $overlayColor;

                                if (preg_match('/^#([A-Fa-f0-9]{6})$/', $overlayColor, $matches)) {
                                    $hex = $matches[1];

                                    $red = hexdec(substr($hex, 0, 2));
                                    $green = hexdec(substr($hex, 2, 2));
                                    $blue = hexdec(substr($hex, 4, 2));

                                    $overlayRgba =
                                        'rgba(' .
                                        $red .
                                        ', ' .
                                        $green .
                                        ', ' .
                                        $blue .
                                        ', ' .
                                        $overlayOpacity .
                                        ')';
                                }
                            @endphp


                            <article
                                class="mcw-hero-slide {{ $index === 0 ? 'is-active' : '' }}"
                                data-slide-index="{{ $index }}"
                            >

                                {{-- ==================================================
                                     FULL-WIDTH HERO IMAGE
                                =================================================== --}}

                                <img
                                    class="mcw-hero-slide-image"
                                    src="{{ asset('storage/' . $slide->image) }}"
                                    alt="{{ $slide->title ?: 'MCW Shop' }}"
                                >


                                {{-- ==================================================
                                     CONFIGURABLE IMAGE OVERLAY
                                =================================================== --}}

                                <div
                                    class="mcw-hero-slide-overlay"
                                    style="background: {{ $overlayRgba }};"
                                ></div>


                                {{-- ==================================================
                                     ALL CONTENT OVER THE IMAGE
                                =================================================== --}}

                                <div
                                    class="
                                        mcw-hero-slide-content-wrapper
                                        position-{{ $contentPosition }}
                                        vertical-{{ $contentVertical }}
                                    "
                                >

                                    <div
                                        class="
                                            mcw-hero-slide-content
                                            align-{{ $textAlignment }}
                                        "
                                    >

                                        @if ($slide->title)

                                            <h1 class="mcw-hero-slide-title">
                                                {{ $slide->title }}
                                            </h1>

                                        @endif


                                        @if ($slide->subtitle)

                                            <div class="mcw-hero-slide-subtitle">
                                                {{ $slide->subtitle }}
                                            </div>

                                        @endif


                                        @if ($slide->description)

                                            <div class="mcw-hero-slide-description">
                                                {!! nl2br(e($slide->description)) !!}
                                            </div>

                                        @endif


                                        @if ($slide->button_text)

                                            <a
                                                class="mcw-hero-slide-button"
                                                href="{{ $slide->button_url ?: '#featured-products' }}"
                                            >
                                                {{ $slide->button_text }}
                                            </a>

                                        @endif

                                    </div>

                                </div>

                            </article>

                        @endforeach



                        @if ($heroSlides->count() > 1)

                            {{-- ==================================================
                                 PREVIOUS
                            =================================================== --}}

                            <button
                                type="button"
                                class="mcw-hero-control previous"
                                id="mcwHeroPrevious"
                                aria-label="Previous slide"
                            >
                                &#10094;
                            </button>


                            {{-- ==================================================
                                 NEXT
                            =================================================== --}}

                            <button
                                type="button"
                                class="mcw-hero-control next"
                                id="mcwHeroNext"
                                aria-label="Next slide"
                            >
                                &#10095;
                            </button>


                            {{-- ==================================================
                                 SLIDE INDICATORS
                            =================================================== --}}

                            <div
                                class="mcw-hero-indicators"
                                id="mcwHeroIndicators"
                            >

                                @foreach ($heroSlides as $index => $slide)

                                    <button
                                        type="button"
                                        class="
                                            mcw-hero-indicator
                                            {{ $index === 0 ? 'is-active' : '' }}
                                        "
                                        data-slide-to="{{ $index }}"
                                        aria-label="Go to slide {{ $index + 1 }}"
                                    ></button>

                                @endforeach

                            </div>

                        @endif

                    </div>

                @else

                    {{-- ==========================================================
                         FALLBACK WHEN NO HERO SLIDE EXISTS
                    =========================================================== --}}

                    <div
                        class="mcw-hero-slide is-active"
                        style="min-height: 420px;"
                    >

                        <div
                            class="mcw-hero-slide-content-wrapper position-center vertical-center"
                            style="min-height: 420px;"
                        >

                            <div
                                class="mcw-hero-slide-content align-center"
                            >

                                <h1 class="mcw-hero-slide-title">
                                    Welcome to MCW Shop
                                </h1>

                                <div class="mcw-hero-slide-subtitle">
                                    Quality products at affordable prices.
                                </div>

                            </div>

                        </div>

                    </div>

                @endif

            </section>



{{-- ==================================================================
     2. FEATURED CATEGORIES
=================================================================== --}}

<section
    class="mcw-homepage-section mcw-featured-categories-section"
    id="featured-categories"
>

    <div class="mcw-homepage-section-inner">

        @if ($featuredCategories->isNotEmpty())

            <div class="mcw-featured-categories-header">

                <div class="mcw-featured-categories-heading">

                    <span class="mcw-featured-categories-eyebrow">
                        Shop by Category
                    </span>

                    <h2 class="mcw-featured-categories-title">
                        Featured Categories
                    </h2>

                    <p class="mcw-featured-categories-description">
                        Explore our featured collections and find the products
                        that are right for you.
                    </p>

                </div>

            </div>


            <div class="mcw-featured-categories-grid">

                @foreach ($featuredCategories as $category)

                    @php
                        $categoryUrl = url(
                            '/category/' . $category->slug
                        );
                    @endphp

                    <a
                        href="{{ $categoryUrl }}"
                        class="mcw-featured-category-card"
                    >

                        <div class="mcw-featured-category-image-wrapper">

                            @if ($category->thumbnail)

                                <img
                                    src="{{ asset('storage/' . $category->thumbnail) }}"
                                    alt="{{ $category->name }}"
                                    class="mcw-featured-category-image"
                                >

                            @else

                                <div class="mcw-featured-category-placeholder">

                                    <span>
                                        {{ strtoupper(substr($category->name, 0, 1)) }}
                                    </span>

                                </div>

                            @endif


                            <div class="mcw-featured-category-image-overlay"></div>


                            <div class="mcw-featured-category-arrow">
                                <span>&rarr;</span>
                            </div>

                        </div>


                        <div class="mcw-featured-category-content">

                            <h3 class="mcw-featured-category-name">
                                {{ $category->name }}
                            </h3>


                            <div class="mcw-featured-category-meta">

                                <span>
                                    {{ number_format($category->active_products_count) }}
                                    {{ $category->active_products_count === 1 ? 'Product' : 'Products' }}
                                </span>

                            </div>

                        </div>

                    </a>

                @endforeach

            </div>

        @else

            <div class="mcw-featured-categories-empty">

                <h2>
                    Featured Categories
                </h2>

                <p>
                    Featured categories will appear here once they are
                    enabled from the admin panel.
                </p>

            </div>

        @endif

    </div>

</section>


{{-- ==================================================================
     3. FEATURED PRODUCTS
=================================================================== --}}

<section
    class="mcw-homepage-section"
    id="featured-products"
>

    <div class="mcw-homepage-section-inner">

        <div class="mcw-featured-products">

            {{-- ----------------------------------------------------------
                 SECTION HEADER
            ----------------------------------------------------------- --}}

            <div class="mcw-featured-products-header">

                <div class="mcw-featured-products-heading">

                    <span class="mcw-featured-products-kicker">
                        Featured Products
                    </span>

                    <h2>
                        Shop Our Featured Collection
                    </h2>

                    <p>
                        Discover some of the products currently available
                        at MCW Shop.
                    </p>

                </div>

            </div>


{{-- ----------------------------------------------------------
     PRODUCT GRID
----------------------------------------------------------- --}}

@if($featuredProducts->count())

    <div class="mcw-featured-products-grid">

        @foreach($featuredProducts as $product)

            @include(
                'home.components.product-card',
                [
                    'product' => $product,
                ]
            )

        @endforeach

    </div>

@else

    <div class="mcw-featured-products-empty">

        <p>
            No featured products are available at the moment.
        </p>

    </div>

@endif

</div>

</div>

</section>

{{-- ==================================================================
     4. PRODUCT SECTIONS
=================================================================== --}}

@php

    /*
    |--------------------------------------------------------------------------
    | Product Sections
    |--------------------------------------------------------------------------
    |
    | Product sections are configured through HomepageSection records.
    |
    | Supported settings:
    |
    | product_limit
    | product_type
    | category_id
    | eyebrow
    |
    | Supported product types:
    |
    | latest
    | category
    |
    */

    $productSections = $homepageSections
        ->filter(function ($section) {

            return $section->is_active
                && str_starts_with(
                    $section->section_key,
                    'products_'
                );

        })
        ->sortBy(function ($section) {

            return [
                $section->sort_order,
                $section->id,
            ];

        });

@endphp


@if ($productSections->isNotEmpty())

    @foreach ($productSections as $productSection)

        @php

            $productLimit =
                $productSection->getSetting(
                    'product_limit',
                    8
                );

            $productLimit = max(
                1,
                min(
                    24,
                    (int) $productLimit
                )
            );


            $productType =
                $productSection->getSetting(
                    'product_type',
                    'latest'
                );


            $categoryId =
                $productSection->getSetting(
                    'category_id'
                );


            /*
            |--------------------------------------------------------------------------
            | Product Query
            |--------------------------------------------------------------------------
            */

            $sectionProducts = \App\Models\Product::query()
                ->where('status', 'active')
                ->where('stock', '>', 0)
                ->with([
                    'primaryImage',
                    'images',
                    'variants',
                    'category',
                    'brand',
                ]);


            /*
            |--------------------------------------------------------------------------
            | Category Products
            |--------------------------------------------------------------------------
            */

            if (
                $productType === 'category'
                && $categoryId
            ) {

                $sectionProducts
                    ->where(
                        'category_id',
                        $categoryId
                    );

            }


            /*
            |--------------------------------------------------------------------------
            | Latest Products
            |--------------------------------------------------------------------------
            */

            $sectionProducts = $sectionProducts
                ->latest()
                ->take($productLimit)
                ->get();

        @endphp


        <section
            class="mcw-homepage-section mcw-product-section"
            id="product-section-{{ $productSection->id }}"
        >

            <div class="mcw-homepage-section-inner">

                <div class="mcw-featured-products">


                    {{-- ======================================================
                         SECTION HEADER
                    ======================================================= --}}

                    <div class="mcw-featured-products-header">

                        <div class="mcw-featured-products-heading">


                            @if (
                                $productSection->getSetting(
                                    'eyebrow'
                                )
                            )

                                <span
                                    class="mcw-featured-products-kicker"
                                >
                                    {{ $productSection->getSetting(
                                        'eyebrow'
                                    ) }}
                                </span>

                            @endif


                            <h2>

                                {{ $productSection->title
                                    ?: $productSection->name }}

                            </h2>


                            @if ($productSection->subtitle)

                                <p>
                                    {{ $productSection->subtitle }}
                                </p>

                            @elseif ($productSection->description)

                                <p>
                                    {{ $productSection->description }}
                                </p>

                            @endif

                        </div>

                    </div>


{{-- ======================================================
     PRODUCTS
======================================================= --}}

@if ($sectionProducts->isNotEmpty())

    <div class="mcw-featured-products-grid">

        @foreach ($sectionProducts as $product)

            @include(
                'home.components.product-card',
                [
                    'product' => $product,
                ]
            )

        @endforeach

    </div>

@else

    <div class="mcw-featured-products-empty">

        <p>
            No products are available in this
            section at the moment.
        </p>

    </div>

@endif

</div>

</div>

</section>

@endforeach

@endif


{{-- ==================================================================
     5. BRAND SHOWCASE
=================================================================== --}}

<section
    class="mcw-homepage-section"
    id="brand-showcase"
>

    <div class="mcw-homepage-section-inner">

        <div class="mcw-brand-showcase">

            {{-- ----------------------------------------------------------
                 SECTION HEADER
            ----------------------------------------------------------- --}}

            <div class="mcw-brand-showcase-header">

                <div class="mcw-brand-showcase-heading">

                    <span class="mcw-brand-showcase-kicker">
                        Our Brands
                    </span>

                    <h2 class="mcw-brand-showcase-title">
                        Shop by Brand
                    </h2>

                    <p class="mcw-brand-showcase-description">
                        Explore products from trusted brands available
                        at MCW Shop.
                    </p>

                </div>

            </div>


            {{-- ----------------------------------------------------------
                 BRAND GRID
            ----------------------------------------------------------- --}}

            @if($brands->count())

                <div class="mcw-brand-showcase-grid">

                    @foreach($brands as $brand)

                        @php

                            $brandInitial =
                                strtoupper(
                                    substr(
                                        $brand->name,
                                        0,
                                        1
                                    )
                                );

                            $brandUrl =
                                url(
                                    '/brand/' . $brand->slug
                                );

                        @endphp


                        <a
                            href="{{ $brandUrl }}"
                            class="mcw-brand-card"
                        >

                            {{-- Brand Logo --}}

                            @if($brand->logo)

                                <div
                                    class="mcw-brand-card-logo"
                                >

                                    <img
                                        src="{{ asset('storage/' . $brand->logo) }}"
                                        alt="{{ $brand->name }}"
                                    >

                                </div>

                            @else

                                <div
                                    class="mcw-brand-card-placeholder"
                                >

                                    {{ $brandInitial }}

                                </div>

                            @endif


                            {{-- Brand Name --}}

                            <h3 class="mcw-brand-card-name">
                                {{ $brand->name }}
                            </h3>


                            {{-- Product Count --}}

                            <div class="mcw-brand-card-products">

                                {{ number_format($brand->active_products_count) }}

                                {{
                                    $brand->active_products_count === 1
                                        ? 'Product'
                                        : 'Products'
                                }}

                            </div>


                            {{-- Arrow --}}

                            <span
                                class="mcw-brand-card-arrow"
                                aria-hidden="true"
                            >
                                &rarr;
                            </span>

                        </a>

                    @endforeach

                </div>

            @else

                {{-- ------------------------------------------------------
                     EMPTY STATE
                ------------------------------------------------------- --}}

                <div class="mcw-brand-showcase-empty">

                    <h3>
                        Our Brands
                    </h3>

                    <p>
                        Active brands will appear here once they are
                        available in the store.
                    </p>

                </div>

            @endif

        </div>

    </div>

</section>


{{-- ==================================================================
     6. PROMOTIONAL CONTENT
=================================================================== --}}

@if(
    isset($homepageSections) &&
    $homepageSections->where('section_key', 'promotional_content')->isNotEmpty()
)

    @php
        $promotionalSection =
            $homepageSections
                ->where('section_key', 'promotional_content')
                ->first();
    @endphp


    @if($promotionalSection->is_active)

        <section
            class="mcw-homepage-section mcw-promotional-content-section"
            id="promotional-content"
        >

            <div class="mcw-homepage-section-inner">


                <div class="mcw-promotional-content-card">


                    {{-- ==================================================
                         PROMOTIONAL IMAGE
                    =================================================== --}}

                    @if($promotionalSection->image)

                        <img
                            src="{{ asset('storage/' . $promotionalSection->image) }}"
                            alt="{{ $promotionalSection->title ?: 'MCW Shop Promotion' }}"
                            class="mcw-promotional-content-image"
                        >

                    @else

                        <div
                            class="mcw-promotional-content-image-placeholder"
                        ></div>

                    @endif


                    {{-- ==================================================
                         IMAGE OVERLAY
                    =================================================== --}}

                    <div
                        class="mcw-promotional-content-overlay"
                    ></div>


                    {{-- ==================================================
                         CONTENT OVER IMAGE
                    =================================================== --}}

                    <div
                        class="
                            mcw-promotional-content-inner
                            {{ $promotionalSection->content_position ?? 'left' }}
                        "
                    >

                        <div class="mcw-promotional-content-content">


                            {{-- ==================================================
                                 TITLE
                            =================================================== --}}

                            @if($promotionalSection->title)

                                <h2 class="mcw-promotional-content-title">
                                    {{ $promotionalSection->title }}
                                </h2>

                            @endif


                            {{-- ==================================================
                                 SUBTITLE
                            =================================================== --}}

                            @if($promotionalSection->subtitle)

                                <div class="mcw-promotional-content-subtitle">
                                    {{ $promotionalSection->subtitle }}
                                </div>

                            @endif


                            {{-- ==================================================
                                 DESCRIPTION
                            =================================================== --}}

                            @if($promotionalSection->description)

                                <div class="mcw-promotional-content-description">
                                    {!! nl2br(e($promotionalSection->description)) !!}
                                </div>

                            @endif


                            {{-- ==================================================
                                 BUTTON
                            =================================================== --}}

                            @if(
                                $promotionalSection->button_text &&
                                $promotionalSection->button_url
                            )

                                <a
                                    href="{{ $promotionalSection->button_url }}"
                                    class="mcw-promotional-content-button"
                                >
                                    {{ $promotionalSection->button_text }}
                                </a>

                            @endif


                        </div>

                    </div>


                </div>

            </div>

        </section>

    @endif

@endif


{{-- ==================================================================
     7. YOUTUBE / MEDIA
=================================================================== --}}

@if (
    isset($homepageSections['youtube-media']) &&
    $homepageSections['youtube-media']->isVisible()
)

    @php
        $youtubeSection =
            $homepageSections['youtube-media'];

        $videoUrl =
            trim((string) $youtubeSection->video_url);

        $youtubeVideoId = null;

        if ($videoUrl) {

            if (
                preg_match(
                    '/(?:youtube\.com\/watch\?v=|youtu\.be\/|youtube\.com\/embed\/)([A-Za-z0-9_-]{11})/',
                    $videoUrl,
                    $matches
                )
            ) {
                $youtubeVideoId = $matches[1];
            }

        }
    @endphp


    @if ($youtubeVideoId)

        <section
            class="mcw-homepage-section mcw-youtube-section"
            id="youtube-media"
        >

            <div class="mcw-homepage-section-inner">

                <div class="mcw-youtube-header">

                    @if ($youtubeSection->subtitle)

                        <span class="mcw-youtube-kicker">
                            {{ $youtubeSection->subtitle }}
                        </span>

                    @endif


                    @if ($youtubeSection->title)

                        <h2 class="mcw-youtube-title">
                            {{ $youtubeSection->title }}
                        </h2>

                    @endif


                    @if ($youtubeSection->description)

                        <p class="mcw-youtube-description">
                            {{ $youtubeSection->description }}
                        </p>

                    @endif

                </div>


                <div class="mcw-youtube-video-wrapper">

                    <div class="mcw-youtube-video">

                        <iframe
                            src="https://www.youtube.com/embed/{{ $youtubeVideoId }}"
                            title="{{ $youtubeSection->title ?: 'MCW Shop YouTube Video' }}"
                            loading="lazy"
                            allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share"
                            allowfullscreen
                        ></iframe>

                    </div>

                </div>


                @if ($youtubeSection->button_text)

                    <div class="mcw-youtube-action">

                        <a
                            href="{{ $youtubeSection->button_url ?: '#' }}"
                            class="mcw-youtube-button"
                            target="_blank"
                            rel="noopener noreferrer"
                        >
                            {{ $youtubeSection->button_text }}
                        </a>

                    </div>

                @endif

            </div>

        </section>

    @endif

@endif


{{-- ==================================================================
     8. TRUST / BENEFITS
=================================================================== --}}

@if (
    isset($homepageSections['trust-benefits']) &&
    $homepageSections['trust-benefits']->isVisible()
)

    @php
        $trustSection =
            $homepageSections['trust-benefits'];

        $benefits =
            $trustSection->getSetting(
                'benefits',
                [
                    [
                        'icon' => '✓',
                        'title' => 'Quality Products',
                        'description' => 'Carefully selected products for our customers.',
                    ],
                    [
                        'icon' => '⚡',
                        'title' => 'Fast Processing',
                        'description' => 'We process your order as quickly as possible.',
                    ],
                    [
                        'icon' => '৳',
                        'title' => 'Cash on Delivery',
                        'description' => 'Pay conveniently when your order arrives.',
                    ],
                    [
                        'icon' => '♥',
                        'title' => 'Customer Support',
                        'description' => 'Our team is here to help when you need us.',
                    ],
                ]
            );
    @endphp


    <section
        class="mcw-homepage-section mcw-trust-section"
        id="trust-benefits"
    >

        <div class="mcw-homepage-section-inner">

            <div class="mcw-trust-header">

                @if ($trustSection->subtitle)

                    <span class="mcw-trust-kicker">
                        {{ $trustSection->subtitle }}
                    </span>

                @endif


                @if ($trustSection->title)

                    <h2 class="mcw-trust-title">
                        {{ $trustSection->title }}
                    </h2>

                @endif


                @if ($trustSection->description)

                    <p class="mcw-trust-description">
                        {{ $trustSection->description }}
                    </p>

                @endif

            </div>


            @if (is_array($benefits) && count($benefits))

                <div class="mcw-trust-grid">

                    @foreach ($benefits as $benefit)

                        <article class="mcw-trust-card">

                            <div class="mcw-trust-icon">
                                {{ $benefit['icon'] ?? '✓' }}
                            </div>


                            <h3 class="mcw-trust-card-title">
                                {{ $benefit['title'] ?? '' }}
                            </h3>


                            <p class="mcw-trust-card-description">
                                {{ $benefit['description'] ?? '' }}
                            </p>

                        </article>

                    @endforeach

                </div>

            @endif

        </div>

    </section>

@endif


{{-- ==================================================================
     9. FAQ
=================================================================== --}}

@if (
    isset($homepageSections['faq']) &&
    $homepageSections['faq']->isVisible()
)

    @php
        $faqSection =
            $homepageSections['faq'];

        $faqs =
            $faqSection->getSetting(
                'faqs',
                [
                    [
                        'question' => 'How can I place an order?',
                        'answer' => 'Select the product you want and use the available order or Buy Now option to complete your order.',
                    ],
                    [
                        'question' => 'Do you offer Cash on Delivery?',
                        'answer' => 'Yes. MCW Shop supports Cash on Delivery for eligible orders.',
                    ],
                    [
                        'question' => 'How will my order be delivered?',
                        'answer' => 'Your order will be processed and delivered using the available delivery service for your area.',
                    ],
                    [
                        'question' => 'Can I contact MCW Shop for support?',
                        'answer' => 'Yes. You can contact MCW Shop through the available support and communication channels.',
                    ],
                ]
            );
    @endphp


    @if (is_array($faqs) && count($faqs))

        <section
            class="mcw-homepage-section mcw-faq-section"
            id="faq"
        >

            <div class="mcw-homepage-section-inner">

                <div class="mcw-faq-header">

                    @if ($faqSection->subtitle)

                        <span class="mcw-faq-kicker">
                            {{ $faqSection->subtitle }}
                        </span>

                    @endif


                    @if ($faqSection->title)

                        <h2 class="mcw-faq-title">
                            {{ $faqSection->title }}
                        </h2>

                    @endif


                    @if ($faqSection->description)

                        <p class="mcw-faq-description">
                            {{ $faqSection->description }}
                        </p>

                    @endif

                </div>


                <div class="mcw-faq-list">

                    @foreach ($faqs as $index => $faq)

                        <article class="mcw-faq-item">

                            <button
                                type="button"
                                class="mcw-faq-question"
                                aria-expanded="false"
                            >

                                <span>
                                    {{ $faq['question'] ?? '' }}
                                </span>


                                <span
                                    class="mcw-faq-question-icon"
                                    aria-hidden="true"
                                >
                                    +
                                </span>

                            </button>


                            <div class="mcw-faq-answer">

                                <div class="mcw-faq-answer-inner">

                                    <div class="mcw-faq-answer-content">

                                        {{ $faq['answer'] ?? '' }}

                                    </div>

                                </div>

                            </div>

                        </article>

                    @endforeach

                </div>

            </div>

        </section>

    @endif

@endif


    {{-- ======================================================================
         EXISTING MCW FOOTER

         DO NOT CREATE A NEW FOOTER HERE.
         Existing file:
         resources/views/frontend/partials/footer.blade.php
    ======================================================================= --}}

    @include('frontend.partials.footer')



    {{-- ======================================================================
         HERO SLIDER JAVASCRIPT
    ======================================================================= --}}

    @if ($heroSlides->count() > 1)

        <script>

            document.addEventListener(
                'DOMContentLoaded',
                function () {

                    const slider =
                        document.getElementById(
                            'mcwHeroSlider'
                        );

                    if (!slider) {
                        return;
                    }


                    const slides =
                        slider.querySelectorAll(
                            '.mcw-hero-slide'
                        );


                    const indicators =
                        slider.querySelectorAll(
                            '.mcw-hero-indicator'
                        );


                    const previousButton =
                        document.getElementById(
                            'mcwHeroPrevious'
                        );


                    const nextButton =
                        document.getElementById(
                            'mcwHeroNext'
                        );


                    let currentIndex = 0;


                    let autoplayTimer = null;


                    const autoplayDelay = 5000;


                    function showSlide(index) {

                        if (!slides.length) {
                            return;
                        }


                        if (index >= slides.length) {
                            index = 0;
                        }


                        if (index < 0) {
                            index = slides.length - 1;
                        }


                        slides.forEach(
                            function (slide, slideIndex) {

                                slide.classList.toggle(
                                    'is-active',
                                    slideIndex === index
                                );

                            }
                        );


                        indicators.forEach(
                            function (indicator, indicatorIndex) {

                                indicator.classList.toggle(
                                    'is-active',
                                    indicatorIndex === index
                                );

                            }
                        );


                        currentIndex = index;

                    }


                    function nextSlide() {

                        showSlide(
                            currentIndex + 1
                        );

                    }


                    function previousSlide() {

                        showSlide(
                            currentIndex - 1
                        );

                    }


                    function stopAutoplay() {

                        if (autoplayTimer !== null) {

                            window.clearInterval(
                                autoplayTimer
                            );

                            autoplayTimer = null;

                        }

                    }


                    function startAutoplay() {

                        stopAutoplay();


                        autoplayTimer =
                            window.setInterval(
                                function () {

                                    nextSlide();

                                },
                                autoplayDelay
                            );

                    }


                    if (nextButton) {

                        nextButton.addEventListener(
                            'click',
                            function () {

                                nextSlide();

                                startAutoplay();

                            }
                        );

                    }


                    if (previousButton) {

                        previousButton.addEventListener(
                            'click',
                            function () {

                                previousSlide();

                                startAutoplay();

                            }
                        );

                    }


                    indicators.forEach(
                        function (indicator) {

                            indicator.addEventListener(
                                'click',
                                function () {

                                    const targetIndex =
                                        parseInt(
                                            indicator.dataset.slideTo,
                                            10
                                        );


                                    if (
                                        Number.isInteger(
                                            targetIndex
                                        )
                                    ) {

                                        showSlide(
                                            targetIndex
                                        );

                                        startAutoplay();

                                    }

                                }
                            );

                        }
                    );


                    slider.addEventListener(
                        'mouseenter',
                        function () {

                            stopAutoplay();

                        }
                    );


                    slider.addEventListener(
                        'mouseleave',
                        function () {

                            startAutoplay();

                        }
                    );


                    slider.addEventListener(
                        'touchstart',
                        function () {

                            stopAutoplay();

                        },
                        {
                            passive: true
                        }
                    );


                    slider.addEventListener(
                        'touchend',
                        function () {

                            startAutoplay();

                        },
                        {
                            passive: true
                        }
                    );


                    showSlide(0);

                    startAutoplay();

                }
            );

        </script>

    @endif


</body>

</html>